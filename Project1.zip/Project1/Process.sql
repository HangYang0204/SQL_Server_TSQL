USE TEMP

GO

 
IF OBJECT_ID('TEMPDB..#COMPLETE',N'U') IS NOT NULL
DROP TABLE #COMPLETE
IF OBJECT_ID('TEMPDB..#T',N'U') IS NOT NULL
DROP TABLE #T
--//STEP 1
SELECT 
	ProductID,DealID,GenProductID,GenDealID
	,ROW_NUMBER() OVER(PARTITION BY GenProductID,ServicesID ORDER BY ProductID) AS RN
	INTO #T
	FROM  RatePlanPlus L
	WHERE NOT EXISTS

	(
		SELECT 1 FROM RatePlan R
		WHERE L.GenProductID = R.ProductID And L.GenDealID = R.dealID
	)

;WITH A AS(
SELECT DISTINCT * FROM #T
)
--//CREATE COMPLETE
SELECT 
		A.ProductID,
		A.DealID,
		A.GenProductID,
		A.GenDealID,
		RP.[productType], 
		RP.[description],
		RP.fee,
		RP.[status], 
		RP.plan_subtype,
		A.RN
INTO #COMPLETE
FROM A  JOIN  RatePlan RP
ON A.ProductID = RP.productID AND A.DealID = RP.dealID

--#RATEPLAN
IF OBJECT_ID('TEMPDB..#RatePlan',N'U') IS NOT NULL
DROP TABLE #RatePlan

select * into #RatePlan
from  RatePlan
where 1 = 2 

declare @max as int, @min as int, @i as int
set @max = (select max(rn) from #COMPLETE)--4


set @i =(select min(rn) from #complete)--1

while @i != @max
	begin
		 

INSERT INTO #RatePlan --25 columns
		(productID, [description],productType,fee,[status],plan_subtype,dealID)
		SELECT 
			ONE.GenProductID AS ProductID,
			LTRIM(RTRIM(ONE.[description])) + ' + ' + LTRIM(RTRIM(TWO.[description])) AS [description], 
			CASE WHEN ONE.ProductType = 'R' OR TWO.ProductType = 'R' THEN 'R' ELSE 'G' END AS ProductType,
			--LEFT(ONE.[description] + ' + ' + TWO.[description],20) AS [Service], --order matters
			ONE.FEE + TWO.FEE AS fee,
			ONE.[STATUS],
			COALESCE(
			CASE WHEN ONE.Plan_Subtype = 'Self-Pay' OR TWO.Plan_Subtype = 'Self-Pay' THEN 'Self-Pay' END,
			CASE WHEN ONE.Plan_Subtype = 'Promo' OR TWO.Plan_Subtype = 'Promo' THEN 'Promo' END,
			CASE WHEN ONE.Plan_Subtype = 'Trial' OR TWO.Plan_Subtype = 'Trial' THEN 'Trial' END,
			CASE WHEN ONE.Plan_Subtype = 'Non-Sub Trial' OR TWO.Plan_Subtype = 'Non-Sub Trial' THEN 'Non-Sub Trial' END,
			CASE WHEN ONE.Plan_Subtype = 'Regular' OR TWO.Plan_Subtype = 'Regular' THEN 'Regular' END,
			CASE WHEN ONE.Plan_Subtype = 'Paid Streaming' OR TWO.Plan_Subtype = 'Paid Streaming' THEN 'Paid Streaming' END,
			CASE WHEN ONE.Plan_Subtype = 'Free Streaming'  OR TWO.Plan_Subtype = 'Free Streaming'  THEN 'Free Streaming' END
			) AS Plan_SubType,
			ONE.GenDealID AS DealID
		FROM (SELECT * FROM #COMPLETE WHERE RN = @i) ONE JOIN (SELECT * FROM #COMPLETE WHERE RN > @i) TWO
		ON ONE.GenProductID = TWO.GenProductID AND ONE.GenDealID = TWO.GenDealID
		

		update c --23 columns
		set c.[description] = r.[description],
			c.ProductType = r.ProductType,
			c.fee = r.fee,
			c.[STATUS] = r.[STATUS],
			c.Plan_SubType = r.Plan_SubType
		from #COMPLETE  c join (select *, ROW_NUMBER() over(partition by productID, dealId order by productsid asc) as rn from #RatePlan) r --desc to asc
		on c.GenProductID = r.productID and c.GenDealID = r.dealID  --c.RN - 1 = r.ProductsID
		where c.RN = @i + 1 --and r.RN = 1--the newer the bigger one.
		and charindex(c.description,r.description) <> 0


		set @i = @i + 1 --2
		if @i < @max						--added if condition
			begin
				;WITH RP AS
				(select productID,
				 ROW_NUMBER() over(partition by productID, dealId order by productsid asc) AS rn FROM #RatePlan )
				DELETE FROM #RatePlan 
				WHERE productID in
				(select productID FROM RP
				WHERE rn > 1)
			end
end


INSERT INTO RatePlan(productID, [description],productType,fee,[status],plan_subtype,dealID)
SELECT 
	productID, [description],productType,fee,[status],plan_subtype,dealID
FROM #RatePlan
 
		 