USE TEMP 

GO

--Create object
IF OBJECT_ID('[dbo].[RatePlanPlus]',N'U') IS NOT NULL
BEGIN
	DROP TABLE [dbo].[RatePlanPlus]
END
CREATE TABLE [dbo].[RatePlanPlus](
	[ServicesID] [bigint] NOT NULL,
	[ProductID] [bigint] NOT NULL,
	[DealID] [bigint] NOT NULL,
	[GenProductID] [bigint] NULL,
	[GenDealID] [bigint] NULL,
	[CNT] [int] NULL,
	[IsCurrent] [bit] NULL
) ON [PRIMARY]

GO


--LOAD RATEPLANPLUS
BULK INSERT dbo.RatePlanPlus
FROM 'C:\Users\Hang.Yang\Documents\RatePlanPlus.csv'
WITH
(
	FIRSTROW = 2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n',
	TABLOCK
)

--Create object
IF OBJECT_ID('[dbo].[RatePlan_staging]',N'U') IS NOT NULL
BEGIN
	DROP TABLE [dbo].[RatePlan]
END
CREATE TABLE [dbo].[RatePlan_staging](
	[ProductsID] [bigint],
	[productID] [bigint] NOT NULL,
	[productType] [varchar](1) NULL,
	[description] [varchar](255) NULL,
	[fee] [real] NULL,
	[status] [varchar](1) NOT NULL,
	[plan_subtype] [varchar](20) NULL,
	[dealID] [bigint] NOT NULL 
)  ON [PRIMARY]

--GO
--IDENTITY(1,1) NOT FOR REPLICATION NOT NULL,
IF OBJECT_ID('[dbo].[RatePlan]',N'U') IS NOT NULL
BEGIN
	DROP TABLE [dbo].[RatePlan]
END
CREATE TABLE [dbo].[RatePlan](
	[ProductsID] [bigint] IDENTITY(1,1),
	[productID] [bigint] NOT NULL,
	[productType] [varchar](1) NULL,
	[description] [varchar](255) NULL,
	[fee] [real] NULL,
	[status] [varchar](1) NOT NULL,
	[plan_subtype] [varchar](20) NULL,
	[dealID] [bigint] NOT NULL 
)  ON [PRIMARY]

GO

--LOAD RATEPLAN
BULK INSERT dbo.RatePlan_staging
FROM 'C:\Users\Hang.Yang\Documents\RatePlan.csv'
WITH
(
	FIRSTROW = 2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n',
	TABLOCK
)

INSERT INTO dbo.RatePlan(productID,productType,description,fee,status,plan_subtype,dealID)
SELECT productID,productType,description,fee,status,plan_subtype,dealID
	FROM RatePlan_staging


--PREPARING
IF OBJECT_ID('tempdb..#SVV',N'U') IS NOT NULL
DROP TABLE #SVV 

SELECT DISTINCT ServicesID,GenProductID,GenDealID
INTO #SVV FROM RatePlanPlus

;WITH A AS(
	SELECT *, ROW_NUMBER()OVER(PARTITION BY GenProductID,GenDealID ORDER BY GenProductID,GenDealID) AS RN
	FROM #SVV 
)

SELECT * FROM A WHERE RN = 1


SELECT DISTINCT GenProductID,GenDealID FROM RatePlanPlus --2102

DELETE FROM RatePlan
FROM RatePlan RP JOIN (SELECT DISTINCT GenProductID,GenDealID FROM RatePlanPlus) RPP
ON RP.productID = RPP.GenProductID AND RP.dealID = RPP.GenDealID

